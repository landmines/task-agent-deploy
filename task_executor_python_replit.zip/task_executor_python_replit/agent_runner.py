import json
import os
from datetime import datetime

AGENT_FILE = "task-executor.json"
LOG_DIR = "logs"

def run_agent(input_data):
    with open(AGENT_FILE, "r", encoding="utf-8") as f:
        agent = json.load(f)

    task = input_data.get("task", "No task provided")
    log = {
        "timestamp": datetime.utcnow().isoformat(),
        "intro": agent.get("introMessage"),
        "behavior": agent.get("behavior"),
        "taskReceived": task,
        "simulated": f"Simulating task: '{task}'...",
        "confirmationNeeded": True
    }

    os.makedirs(LOG_DIR, exist_ok=True)
    log_file = os.path.join(LOG_DIR, f"log-{datetime.utcnow().timestamp()}.json")
    with open(log_file, "w", encoding="utf-8") as log_f:
        json.dump(log, log_f, indent=2)

    return log
